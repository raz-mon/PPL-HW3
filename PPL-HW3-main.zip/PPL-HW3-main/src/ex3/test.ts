import { concat } from "ramda";




console.log(concat([1,2,3], [4]));
console.log([1,2,3].length);
